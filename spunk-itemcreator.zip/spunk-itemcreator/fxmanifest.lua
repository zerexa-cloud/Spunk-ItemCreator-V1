fx_version 'cerulean'
game 'gta5'

name        'spunk-itemcreator'
description 'Item Creator - Easily create ox_inventory items in-game'
author      'Murda Fisher'
version     '2.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    'locales/*.lua',
}

client_scripts {
    'client.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
}

lua54 'yes'
