-- ============================================================
--  spunk-itemcreator | server.lua
--  Storage: Config.StorageMode = 'database' | 'file'
-- ============================================================

-- ── Locale helper ──
local Locale = {}

local function loadLocale()
    local path = GetResourcePath(GetCurrentResourceName()) .. '/locales/' .. (Config.Locale or 'en') .. '.lua'
    local f    = io.open(path, 'r')
    if not f then
        -- fallback to English
        path = GetResourcePath(GetCurrentResourceName()) .. '/locales/en.lua'
        f    = io.open(path, 'r')
    end
    if f then f:close() end
    -- Locales are already loaded as shared_scripts; just reference the table
end

---@param key string
---@param ... any
---@return string
local function T(key, ...)
    -- Locale table is loaded by the shared_script; we reference it directly.
    -- Fallback to key name if translation missing.
    local str = (Locale and Locale[key]) or key
    if select('#', ...) > 0 then
        str = string.format(str:gsub('%%s', '%%s'):gsub('%%d', '%%d'), ...)
    end
    return str
end

-- Shared locale files export a `return Translations` table.
-- We load them here on server start so T() works.
CreateThread(function()
    Wait(0) -- let shared scripts finish
    local ok, result = pcall(function()
        local locale = Config.Locale or 'en'
        -- The locales/*.lua files are shared_scripts, so they run on both sides.
        -- On the server side we re-read the return value for T().
        local chunk, err = load(LoadResourceFile(GetCurrentResourceName(), 'locales/' .. locale .. '.lua'))
        if not chunk then
            chunk = load(LoadResourceFile(GetCurrentResourceName(), 'locales/en.lua'))
        end
        if chunk then
            Locale = chunk() or {}
        end
    end)
    if not ok then
        print('^3[spunk-itemcreator] Could not load locale: ' .. tostring(result) .. '^0')
    end
end)

-- ── Admin check ──
local function isAdmin(source)
    if IsPlayerAceAllowed(source, 'itemcreator.use') then return true end
    local group = GetPlayerGroup(source) or ''
    for _, g in ipairs(Config.AdminGroups) do
        if group == g then return true end
    end
    return false
end

-- ── Notify helper ──
local function notify(source, notifyType, key, ...)
    local msg = T(key, ...)
    TriggerClientEvent('spunk-itemcreator:client:notify', source, notifyType, msg)
end

-- ── Sanitise item name ──
local function validName(name)
    return type(name) == 'string' and name:match('^[a-z0-9_]+$') ~= nil and #name >= 1 and #name <= 64
end

-- ── Format Lua entry string ──
local function buildLuaEntry(data)
    local weight     = tonumber(data.weight)   or 100
    local stack      = data.stack      == true or data.stack      == 'true'
    local useable    = data.useable    == true or data.useable    == 'true'
    local closeOnUse = data.closeOnUse == true or data.closeOnUse == 'true'
    local image      = tostring(data.image or (data.name .. '.png'))
    local desc       = tostring(data.description or ''):gsub("'", "\\'")
    local label      = tostring(data.label or ''):gsub("'", "\\'")

    return string.format(
        "    ['%s'] = {\n"     ..
        "        label       = '%s',\n"  ..
        "        weight      = %d,\n"   ..
        "        stack       = %s,\n"   ..
        "        useable     = %s,\n"   ..
        "        shouldClose = %s,\n"   ..
        "        image       = '%s',\n" ..
        "        description = '%s',\n" ..
        "    },",
        data.name, label, weight,
        tostring(stack), tostring(useable), tostring(closeOnUse),
        image, desc
    )
end

-- ── File helpers ──
local function getSavePath()
    return GetResourcePath(GetCurrentResourceName()) .. '/saves/'
end

local function ensureSaveDir()
    local path = getSavePath()
    os.execute('mkdir "' .. path:gsub('/', '\\') .. '" 2>nul')
end

local function appendToFile(entry)
    ensureSaveDir()
    local file = io.open(getSavePath() .. 'items_export.txt', 'a')
    if file then
        file:write(entry .. '\n\n')
        file:close()
        return true
    end
    return false
end

local function readFileItems()
    local items = {}
    local file  = io.open(getSavePath() .. 'items_export.txt', 'r')
    if file then
        local content = file:read('*a')
        file:close()
        for block in content:gmatch("(%['[^']+']%s*=%s*{[^}]+}),") do
            items[#items + 1] = block
        end
    end
    return items
end

local function deleteFromFile(itemName)
    local file = io.open(getSavePath() .. 'items_export.txt', 'r')
    if not file then return false end
    local content = file:read('*a')
    file:close()

    local escaped  = itemName:gsub('[%-%.%+%[%]%(%)%$%^%%%?%*]', '%%%1')
    local pattern  = "    %['" .. escaped .. "'%]%s*=%s*{[^}]+},\n?\n?"
    local newContent, n = content:gsub(pattern, '')
    if n == 0 then return false end

    local wFile = io.open(getSavePath() .. 'items_export.txt', 'w')
    if wFile then
        wFile:write(newContent)
        wFile:close()
        return true
    end
    return false
end

-- ============================================================
--  DATABASE MODE  (oxmysql)
-- ============================================================

local function dbCreateItem(data, cb)
    local weight     = tonumber(data.weight)   or 100
    local stack      = (data.stack      == true or data.stack      == 'true') and 1 or 0
    local useable    = (data.useable    == true or data.useable    == 'true') and 1 or 0
    local closeOnUse = (data.closeOnUse == true or data.closeOnUse == 'true') and 1 or 0

    MySQL.query(
        [[INSERT INTO `]] .. Config.DBTable .. [[`
            (name, label, description, weight, image, category, stack, useable, close_on_use)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            label       = VALUES(label),
            description = VALUES(description),
            weight      = VALUES(weight),
            image       = VALUES(image),
            category    = VALUES(category),
            stack       = VALUES(stack),
            useable     = VALUES(useable),
            close_on_use= VALUES(close_on_use)
        ]],
        {
            data.name,
            data.label,
            data.description or '',
            weight,
            data.image or (data.name .. '.png'),
            data.category or '',
            stack,
            useable,
            closeOnUse,
        },
        function(result)
            if result and result.affectedRows and result.affectedRows > 0 then
                cb(true)
            else
                cb(false)
            end
        end
    )
end

local function dbGetItems(cb)
    MySQL.query(
        'SELECT * FROM `' .. Config.DBTable .. '` ORDER BY created_at DESC',
        {},
        function(rows)
            local items = {}
            if rows then
                for _, row in ipairs(rows) do
                    items[#items + 1] = {
                        name        = row.name,
                        label       = row.label,
                        description = row.description or '',
                        weight      = tonumber(row.weight) or 0,
                        image       = row.image or (row.name .. '.png'),
                        category    = row.category or '',
                        stack       = row.stack      == 1,
                        useable     = row.useable    == 1,
                        closeOnUse  = row.close_on_use == 1,
                        source      = 'database',
                    }
                end
            end
            cb(items)
        end
    )
end

local function dbDeleteItem(itemName, cb)
    MySQL.query(
        'DELETE FROM `' .. Config.DBTable .. '` WHERE name = ?',
        { itemName },
        function(result)
            if result and result.affectedRows and result.affectedRows > 0 then
                cb(true)
            else
                cb(false)
            end
        end
    )
end

-- ============================================================
--  CREATE ITEM
-- ============================================================
RegisterNetEvent('spunk-itemcreator:server:createItem')
AddEventHandler('spunk-itemcreator:server:createItem', function(data)
    local src = source

    if not isAdmin(src) then
        notify(src, 'error', 'notify_no_permission')
        return
    end

    -- Validate
    if not data or not validName(data.name) then
        notify(src, 'error', 'notify_invalid_name')
        return
    end

    if not data.label or data.label == '' then
        notify(src, 'error', 'notify_invalid_label')
        return
    end

    local luaEntry = buildLuaEntry(data)

    print(string.format('^2[spunk-itemcreator]^0 %s created item: %s (label: %s)',
        GetPlayerName(src), data.name, data.label))

    if Config.StorageMode == 'database' then

        dbCreateItem(data, function(success)
            if not success then
                notify(src, 'error', 'notify_db_error')
                return
            end

            -- Optionally also export to flat file as backup
            if Config.AlsoExportToFile then
                appendToFile(luaEntry)
            end

            notify(src, 'success', 'notify_created', data.label)
            TriggerClientEvent('spunk-itemcreator:client:itemCreated', src, luaEntry, data)
        end)

    else
        -- File mode
        if appendToFile(luaEntry) then
            notify(src, 'success', 'notify_created', data.label)
            TriggerClientEvent('spunk-itemcreator:client:itemCreated', src, luaEntry, data)
        else
            notify(src, 'error', 'notify_db_error')
        end
    end
end)

-- ============================================================
--  GET ALL ITEMS  (ox_inventory shared items + our saved items)
-- ============================================================

--- Reads every item registered in ox_inventory and returns a
--- flat array of plain tables  { name, label, weight, ... }
local function getOxItems()
    local result = {}

    -- ox_inventory exposes its items table via exports
    local ok, oxItems = pcall(function()
        return exports.ox_inventory:Items()
    end)

    if ok and type(oxItems) == 'table' then
        for name, data in pairs(oxItems) do
            if type(data) == 'table' then
                result[#result + 1] = {
                    name        = tostring(name),
                    label       = tostring(data.label       or name),
                    description = tostring(data.description or ''),
                    weight      = tonumber(data.weight)     or 0,
                    image       = tostring(data.image       or (name .. '.png')),
                    category    = tostring(data.category    or ''),
                    stack       = data.stack       == true  or data.stack       == 1,
                    useable     = data.useable     == true  or data.useable     == 1,
                    closeOnUse  = data.shouldClose == true  or data.shouldClose == 1,
                    source      = 'ox_inventory',
                }
            end
        end
        -- Sort alphabetically by name
        table.sort(result, function(a, b) return a.name < b.name end)
    else
        print('^3[spunk-itemcreator] Could not read ox_inventory items: ' .. tostring(oxItems) .. '^0')
    end

    return result
end

--- Merges ox_inventory items with our DB/file items.
--- Our items override ox_inventory entries with the same name
--- so the admin can see the exact data that was saved here.
local function getMergedItems(ourItems)
    if not Config.ShowOxItems then
        return ourItems
    end

    -- Index our items by name for O(1) lookup
    local ours = {}
    for _, item in ipairs(ourItems) do
        ours[item.name] = item
    end

    local oxItems = getOxItems()
    local merged  = {}
    local seen    = {}

    -- Start with all ox_inventory items, overriding with ours where name matches
    for _, oxItem in ipairs(oxItems) do
        seen[oxItem.name] = true
        merged[#merged + 1] = ours[oxItem.name] or oxItem
    end

    -- Append any items we created that ox_inventory doesn't know about yet
    for _, item in ipairs(ourItems) do
        if not seen[item.name] then
            merged[#merged + 1] = item
        end
    end

    return merged
end

RegisterNetEvent('spunk-itemcreator:server:getItems')
AddEventHandler('spunk-itemcreator:server:getItems', function()
    local src = source
    if not isAdmin(src) then return end

    if Config.StorageMode == 'database' then
        dbGetItems(function(ourItems)
            local merged = getMergedItems(ourItems)
            TriggerClientEvent('spunk-itemcreator:client:receiveItems', src, merged)
        end)
    else
        -- File mode: parse flat file back into objects
        local blocks = readFileItems()
        local ourItems = {}
        for _, block in ipairs(blocks) do
            local item = {}
            item.name        = block:match("^%s*%['([^']+)'%]")
            item.label       = block:match("label%s*=%s*'([^']*)'")
            item.description = block:match("description%s*=%s*'([^']*)'") or ''
            item.weight      = tonumber(block:match("weight%s*=%s*(%d+)")) or 0
            item.image       = block:match("image%s*=%s*'([^']*)'") or ''
            item.stack       = block:find("stack%s*=%s*true") ~= nil
            item.useable     = block:find("useable%s*=%s*true") ~= nil
            item.closeOnUse  = block:find("shouldClose%s*=%s*true") ~= nil
            item.source      = 'file'
            if item.name then ourItems[#ourItems + 1] = item end
        end
        local merged = getMergedItems(ourItems)
        TriggerClientEvent('spunk-itemcreator:client:receiveItems', src, merged)
    end
end)

-- ============================================================
--  DELETE ITEM
-- ============================================================
RegisterNetEvent('spunk-itemcreator:server:deleteItem')
AddEventHandler('spunk-itemcreator:server:deleteItem', function(itemName)
    local src = source
    if not isAdmin(src) then return end

    if not validName(itemName) then return end

    if Config.StorageMode == 'database' then

        dbDeleteItem(itemName, function(success)
            if success then
                -- Keep file in sync if AlsoExportToFile is on
                if Config.AlsoExportToFile then
                    deleteFromFile(itemName)
                end
                notify(src, 'success', 'notify_deleted', itemName)
            else
                notify(src, 'error', 'notify_not_found', itemName)
            end
        end)

    else
        if deleteFromFile(itemName) then
            notify(src, 'success', 'notify_deleted', itemName)
        else
            notify(src, 'error', 'notify_not_found', itemName)
        end
    end
end)
