-- Bulgarian Locale / Български Език
local Translations = {
    -- General
    ['title']                   = 'Създател на Предмети',
    ['subtitle']                = 'Мениджър за ox_inventory',

    -- Tabs
    ['tab_create']              = 'Създай Предмет',
    ['tab_list']                = 'Списък',
    ['tab_preview']             = 'Преглед',

    -- Form Fields
    ['field_name']              = 'Системно Име',
    ['field_name_placeholder']  = 'напр. iron_ore',
    ['field_name_hint']         = 'Само малки букви, цифри и долна черта',
    ['field_label']             = 'Показвано Название',
    ['field_label_placeholder'] = 'напр. Железна Руда',
    ['field_description']       = 'Описание',
    ['field_desc_placeholder']  = 'Незадължително описание...',
    ['field_weight']            = 'Тегло (грама)',
    ['field_image']             = 'Изображение',
    ['field_image_placeholder'] = 'item_name.png или пълен URL',
    ['field_category']          = 'Категория',

    -- Categories
    ['cat_none']                = 'Изберете категория...',
    ['cat_weapon']              = 'Оръжие',
    ['cat_ammo']                = 'Муниции',
    ['cat_food']                = 'Храна и Напитки',
    ['cat_drug']                = 'Наркотици',
    ['cat_tool']                = 'Инструмент',
    ['cat_clothing']            = 'Облекло',
    ['cat_electronic']          = 'Електроника',
    ['cat_medical']             = 'Медицина',
    ['cat_material']            = 'Материал',
    ['cat_document']            = 'Документ',
    ['cat_container']           = 'Контейнер',
    ['cat_misc']                = 'Разни',

    -- Toggles
    ['toggle_stackable']        = 'Стекируемо',
    ['toggle_stackable_desc']   = 'Предметите могат да се стекират в един слот',
    ['toggle_useable']          = 'Използваемо',
    ['toggle_useable_desc']     = 'Предметът може да се използва от инвентара',
    ['toggle_close_on_use']     = 'Затвори при Използване',
    ['toggle_close_desc']       = 'Инвентарът се затваря при използване',

    -- Buttons
    ['btn_create']              = 'Създай Предмет',
    ['btn_reset']               = 'Изчисти Формата',
    ['btn_refresh']             = 'Обнови',
    ['btn_delete']              = 'Изтрий',
    ['btn_copy']                = 'Копирай Код',
    ['btn_copied']              = 'Копирано!',
    ['btn_confirm_delete']      = 'Потвърди Изтриването',
    ['btn_cancel']              = 'Отказ',

    -- Preview Tab
    ['preview_title']           = 'Генериран Lua Код',
    ['preview_card']            = 'Преглед на Предмета',
    ['preview_empty']           = 'Създайте предмет, за да видите преглед тук.',
    ['preview_weight']          = 'Тегло',
    ['preview_stackable']       = 'Стекируемо',
    ['preview_useable']         = 'Използваемо',
    ['preview_close']           = 'Затвори при Използване',

    -- Item List
    ['list_empty']              = 'Няма намерени предмети. Създайте първия си предмет!',
    ['list_weight_unit']        = 'г',
    ['list_confirm_delete']     = 'Сигурни ли сте, че искате да изтриете "%s"? Това не може да бъде отменено.',
    ['list_search']             = 'Търси предмети...',
    ['list_count']              = '%d предмета',

    -- Notifications (server-side)
    ['notify_created']          = 'Предметът "%s" е създаден успешно.',
    ['notify_deleted']          = 'Предметът "%s" е изтрит успешно.',
    ['notify_no_permission']    = 'Нямате право да използвате тази команда.',
    ['notify_invalid_name']     = 'Името на предмета е невалидно. Използвайте само малки букви, цифри и долна черта.',
    ['notify_invalid_label']    = 'Названието на предмета не може да е празно.',
    ['notify_already_exists']   = 'Предмет с името "%s" вече съществува.',
    ['notify_db_error']         = 'Възникна грешка в базата данни. Моля опитайте отново.',
    ['notify_not_found']        = 'Предметът "%s" не беше намерен.',

    -- Yes/No
    ['yes']                     = 'Да',
    ['no']                      = 'Не',
}

if GetCurrentResourceName then
    if lib then
        lib.setLocale(Translations)
    end
end

return Translations
