-- English Locale
local Translations = {
    -- General
    ['title']                   = 'Item Creator',
    ['subtitle']                = 'ox_inventory Item Manager',

    -- Tabs
    ['tab_create']              = 'Create Item',
    ['tab_list']                = 'Item List',
    ['tab_preview']             = 'Preview',

    -- Form Fields
    ['field_name']              = 'System Name',
    ['field_name_placeholder']  = 'e.g. iron_ore',
    ['field_name_hint']         = 'Lowercase, numbers and underscores only',
    ['field_label']             = 'Display Label',
    ['field_label_placeholder'] = 'e.g. Iron Ore',
    ['field_description']       = 'Description',
    ['field_desc_placeholder']  = 'Optional item description...',
    ['field_weight']            = 'Weight (grams)',
    ['field_image']             = 'Image',
    ['field_image_placeholder'] = 'item_name.png or full URL',
    ['field_category']          = 'Category',

    -- Categories
    ['cat_none']                = 'Select category...',
    ['cat_weapon']              = 'Weapon',
    ['cat_ammo']                = 'Ammunition',
    ['cat_food']                = 'Food & Drink',
    ['cat_drug']                = 'Drug',
    ['cat_tool']                = 'Tool',
    ['cat_clothing']            = 'Clothing',
    ['cat_electronic']          = 'Electronic',
    ['cat_medical']             = 'Medical',
    ['cat_material']            = 'Material',
    ['cat_document']            = 'Document',
    ['cat_container']           = 'Container',
    ['cat_misc']                = 'Miscellaneous',

    -- Toggles
    ['toggle_stackable']        = 'Stackable',
    ['toggle_stackable_desc']   = 'Multiple items can stack in one slot',
    ['toggle_useable']          = 'Useable',
    ['toggle_useable_desc']     = 'Item can be used from inventory',
    ['toggle_close_on_use']     = 'Close on Use',
    ['toggle_close_desc']       = 'Inventory closes when item is used',

    -- Buttons
    ['btn_create']              = 'Create Item',
    ['btn_reset']               = 'Reset Form',
    ['btn_refresh']             = 'Refresh',
    ['btn_delete']              = 'Delete',
    ['btn_copy']                = 'Copy Code',
    ['btn_copied']              = 'Copied!',
    ['btn_confirm_delete']      = 'Confirm Delete',
    ['btn_cancel']              = 'Cancel',

    -- Preview Tab
    ['preview_title']           = 'Generated Lua Code',
    ['preview_card']            = 'Item Card Preview',
    ['preview_empty']           = 'Create an item to see the preview here.',
    ['preview_weight']          = 'Weight',
    ['preview_stackable']       = 'Stackable',
    ['preview_useable']         = 'Useable',
    ['preview_close']           = 'Close on Use',

    -- Item List
    ['list_empty']              = 'No items found. Create your first item!',
    ['list_weight_unit']        = 'g',
    ['list_confirm_delete']     = 'Are you sure you want to delete "%s"? This cannot be undone.',
    ['list_search']             = 'Search items...',
    ['list_count']              = '%d items',

    -- Notifications (server-side)
    ['notify_created']          = 'Item "%s" created successfully.',
    ['notify_deleted']          = 'Item "%s" deleted successfully.',
    ['notify_no_permission']    = 'You do not have permission to use this command.',
    ['notify_invalid_name']     = 'Item name is invalid. Use lowercase letters, numbers, and underscores only.',
    ['notify_invalid_label']    = 'Item label cannot be empty.',
    ['notify_already_exists']   = 'An item with the name "%s" already exists.',
    ['notify_db_error']         = 'A database error occurred. Please try again.',
    ['notify_not_found']        = 'Item "%s" was not found.',

    -- Yes/No
    ['yes']                     = 'Yes',
    ['no']                      = 'No',
}

if GetCurrentResourceName then
    -- Running inside FiveM — register with ox_lib
    if lib then
        lib.setLocale(Translations)
    end
end

return Translations
