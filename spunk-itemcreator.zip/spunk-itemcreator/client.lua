-- ============================================================
--  spunk-itemcreator | client.lua
-- ============================================================

local isOpen   = false
local Locale   = {}

-- ── Load locale strings from file ──
CreateThread(function()
    Wait(0)
    local locale = Config.Locale or 'en'
    local chunk, err = load(LoadResourceFile(GetCurrentResourceName(), 'locales/' .. locale .. '.lua'))
    if not chunk then
        chunk = load(LoadResourceFile(GetCurrentResourceName(), 'locales/en.lua'))
    end
    if chunk then
        Locale = chunk() or {}
    end
end)

-- ── Open UI ──
local function OpenUI()
    isOpen = true
    SetNuiFocus(true, true)

    -- Send locale table to NUI so JS can apply translations
    SendNUIMessage({
        action = 'setLocale',
        locale = Locale,
    })

    SendNUIMessage({ action = 'open' })

    -- Request item list from server
    TriggerServerEvent('spunk-itemcreator:server:getItems')
end

-- ── Close UI ──
local function CloseUI()
    isOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

-- ── Command ──
RegisterCommand(Config.Command or 'itemcreator', function()
    if isOpen then CloseUI() else OpenUI() end
end, false)

-- ── Key mapping ──
if Config.KeyMapping and Config.KeyMapping ~= '' then
    RegisterKeyMapping(
        Config.Command or 'itemcreator',
        'Open Item Creator',
        'keyboard',
        Config.KeyMapping
    )
end

-- ── NUI Callbacks ──

RegisterNUICallback('close', function(_, cb)
    CloseUI()
    cb('ok')
end)

RegisterNUICallback('createItem', function(data, cb)
    TriggerServerEvent('spunk-itemcreator:server:createItem', data)
    cb('ok')
end)

RegisterNUICallback('deleteItem', function(data, cb)
    TriggerServerEvent('spunk-itemcreator:server:deleteItem', data.name)
    cb('ok')
end)

RegisterNUICallback('refreshItems', function(_, cb)
    TriggerServerEvent('spunk-itemcreator:server:getItems')
    cb('ok')
end)

-- ── Server → Client ──

RegisterNetEvent('spunk-itemcreator:client:receiveItems')
AddEventHandler('spunk-itemcreator:client:receiveItems', function(items)
    SendNUIMessage({
        action = 'receiveItems',
        items  = items,
    })
end)

RegisterNetEvent('spunk-itemcreator:client:itemCreated')
AddEventHandler('spunk-itemcreator:client:itemCreated', function(code, itemData)
    SendNUIMessage({
        action = 'itemCreated',
        code   = code,
        data   = itemData,
    })
end)

RegisterNetEvent('spunk-itemcreator:client:notify')
AddEventHandler('spunk-itemcreator:client:notify', function(notifyType, msg)
    -- Show in NUI as a toast
    SendNUIMessage({
        action      = 'notify',
        notifyType  = notifyType,
        message     = msg,
    })

    -- Also show via ox_lib if available
    if lib and lib.notify then
        lib.notify({
            title       = Locale['title'] or 'Item Creator',
            description = msg,
            type        = notifyType,
            duration    = Config.NotifyDuration or 4000,
            position    = Config.NotifyPosition  or 'top-right',
        })
    end
end)

-- ── ESC key closes the panel ──
CreateThread(function()
    while true do
        Wait(0)
        if isOpen and IsControlJustReleased(0, 200) then
            CloseUI()
        end
    end
end)
