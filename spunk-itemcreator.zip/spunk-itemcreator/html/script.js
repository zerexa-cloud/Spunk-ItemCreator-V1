/* ============================================================
   spunk-itemcreator — script.js
   ============================================================ */

'use strict';

// ── Locale strings (populated by NUI message from Lua) ──
let L = {
    title:                  'Item Creator',
    subtitle:               'ox_inventory Item Manager',
    tab_create:             'Create Item',
    tab_list:               'Item List',
    tab_preview:            'Preview',
    field_name:             'System Name',
    field_name_placeholder: 'e.g. iron_ore',
    field_name_hint:        'Lowercase, numbers and underscores only',
    field_label:            'Display Label',
    field_label_placeholder:'e.g. Iron Ore',
    field_description:      'Description',
    field_desc_placeholder: 'Optional item description...',
    field_weight:           'Weight (grams)',
    field_image:            'Image',
    field_image_placeholder:'item_name.png or full URL',
    field_category:         'Category',
    cat_none:               'Select category...',
    cat_weapon:             'Weapon',
    cat_ammo:               'Ammunition',
    cat_food:               'Food & Drink',
    cat_drug:               'Drug',
    cat_tool:               'Tool',
    cat_clothing:           'Clothing',
    cat_electronic:         'Electronic',
    cat_medical:            'Medical',
    cat_material:           'Material',
    cat_document:           'Document',
    cat_container:          'Container',
    cat_misc:               'Miscellaneous',
    toggle_stackable:       'Stackable',
    toggle_stackable_desc:  'Multiple items can stack in one slot',
    toggle_useable:         'Useable',
    toggle_useable_desc:    'Item can be used from inventory',
    toggle_close_on_use:    'Close on Use',
    toggle_close_desc:      'Inventory closes when item is used',
    btn_create:             'Create Item',
    btn_reset:              'Reset Form',
    btn_refresh:            'Refresh',
    btn_delete:             'Delete',
    btn_copy:               'Copy Code',
    btn_copied:             'Copied!',
    btn_confirm_delete:     'Confirm Delete',
    btn_cancel:             'Cancel',
    preview_title:          'Generated Lua Code',
    preview_card:           'Item Card Preview',
    preview_empty:          'Create an item to see the preview here.',
    preview_weight:         'Weight',
    preview_stackable:      'Stackable',
    preview_useable:        'Useable',
    preview_close:          'Close on Use',
    list_empty:             'No items found. Create your first item!',
    list_weight_unit:       'g',
    list_confirm_delete:    'Are you sure you want to delete "%s"? This cannot be undone.',
    list_search:            'Search items...',
    list_count:             '%d items',
    yes:                    'Yes',
    no:                     'No',
};

// ── State ──
let allItems        = [];   // raw item objects parsed from server
let pendingDelete   = null; // item name waiting for confirmation

// ── DOM refs ──
const app           = document.getElementById('app');
const closeBtn      = document.getElementById('closeBtn');
const tabBtns       = document.querySelectorAll('.tab-btn');
const tabContents   = document.querySelectorAll('.tab-content');
const itemForm      = document.getElementById('itemForm');
const resetBtn      = document.getElementById('resetBtn');
const searchInput   = document.getElementById('searchInput');
const refreshBtn    = document.getElementById('refreshBtn');
const itemList      = document.getElementById('itemList');
const listEmpty     = document.getElementById('listEmpty');
const itemCountBadge= document.getElementById('itemCountBadge');
const previewDot    = document.getElementById('previewDot');
const previewEmpty  = document.getElementById('previewEmpty');
const previewContent= document.getElementById('previewContent');
const codeContent   = document.getElementById('codeContent');
const copyBtn       = document.getElementById('copyBtn');
const copyBtnText   = document.getElementById('copyBtnText');
const cardLabel     = document.getElementById('cardLabel');
const cardName      = document.getElementById('cardName');
const cardDesc      = document.getElementById('cardDesc');
const cardBadges    = document.getElementById('cardBadges');
const cardImage     = document.getElementById('cardImage');
const cardImgPlaceholder = document.getElementById('cardImgPlaceholder');
const imagePreview  = document.getElementById('imagePreview');
const deleteModal   = document.getElementById('deleteModal');
const modalMessage  = document.getElementById('modalMessage');
const confirmDeleteBtn  = document.getElementById('confirmDeleteBtn');
const cancelDeleteBtn   = document.getElementById('cancelDeleteBtn');
const toastContainer    = document.getElementById('toastContainer');

// ── i18n helpers ──
function t(key, ...args) {
    let str = L[key] || key;
    args.forEach(a => { str = str.replace('%s', a).replace('%d', a); });
    return str;
}

function applyLocale() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (L[key]) el.textContent = L[key];
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.getAttribute('data-i18n-placeholder');
        if (L[key]) el.placeholder = L[key];
    });
}

// ── Tab switching ──
function switchTab(tabName) {
    tabBtns.forEach(btn => {
        const active = btn.dataset.tab === tabName;
        btn.classList.toggle('active', active);
        btn.setAttribute('aria-selected', String(active));
    });
    tabContents.forEach(content => {
        content.classList.toggle('active', content.id === `tab-${tabName}`);
    });
}

tabBtns.forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});

// ── Open / Close UI ──
function openUI() {
    app.classList.remove('hidden');
    document.getElementById('itemName').focus();
}

function closeUI() {
    app.classList.add('hidden');
    fetch('https://spunk-itemcreator/close', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
    }).catch(() => {});
}

closeBtn.addEventListener('click', closeUI);

// ── Image preview ──
const itemImageInput = document.getElementById('itemImage');

function updateImagePreview(url) {
    const existing = imagePreview.querySelector('img');
    if (existing) existing.remove();
    const placeholder = imagePreview.querySelector('.img-placeholder-icon');

    if (url && url.trim() !== '') {
        const img = document.createElement('img');
        img.src = url.trim();
        img.alt = 'Preview';
        img.style.cssText = 'width:100%;height:100%;object-fit:contain;';
        img.onerror = () => {
            img.remove();
            if (placeholder) placeholder.style.display = '';
        };
        img.onload  = () => { if (placeholder) placeholder.style.display = 'none'; };
        if (placeholder) placeholder.style.display = 'none';
        imagePreview.appendChild(img);
    } else {
        if (placeholder) placeholder.style.display = '';
    }
}

itemImageInput.addEventListener('input', () => updateImagePreview(itemImageInput.value));

// Auto-fill image field from name
document.getElementById('itemName').addEventListener('input', function () {
    const nameVal = this.value.trim();
    if (itemImageInput.value === '' || itemImageInput.dataset.autoFilled === 'true') {
        const suggested = nameVal ? `${nameVal}.png` : '';
        itemImageInput.value = suggested;
        itemImageInput.dataset.autoFilled = 'true';
        updateImagePreview(suggested);
    }
    // Enforce lowercase + valid chars
    this.value = this.value.toLowerCase().replace(/[^a-z0-9_]/g, '');
});

itemImageInput.addEventListener('input', function () {
    delete this.dataset.autoFilled;
});

// ── Form validation ──
function validateForm() {
    let valid = true;
    const nameInput  = document.getElementById('itemName');
    const labelInput = document.getElementById('itemLabel');
    const nameError  = document.getElementById('nameError');
    const labelError = document.getElementById('labelError');

    nameError.textContent  = '';
    labelError.textContent = '';
    nameInput.classList.remove('error');
    labelInput.classList.remove('error');

    const nameVal  = nameInput.value.trim();
    const labelVal = labelInput.value.trim();

    if (!nameVal) {
        nameError.textContent = 'System name is required.';
        nameInput.classList.add('error');
        valid = false;
    } else if (!/^[a-z0-9_]+$/.test(nameVal)) {
        nameError.textContent = t('field_name_hint');
        nameInput.classList.add('error');
        valid = false;
    }

    if (!labelVal) {
        labelError.textContent = 'Display label is required.';
        labelInput.classList.add('error');
        valid = false;
    }

    return valid;
}

// ── Form submit ──
itemForm.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!validateForm()) return;

    const data = {
        name:        document.getElementById('itemName').value.trim(),
        label:       document.getElementById('itemLabel').value.trim(),
        description: document.getElementById('itemDesc').value.trim(),
        weight:      parseInt(document.getElementById('itemWeight').value) || 100,
        image:       document.getElementById('itemImage').value.trim() || `${document.getElementById('itemName').value.trim()}.png`,
        category:    document.getElementById('itemCategory').value,
        stack:       document.getElementById('itemStack').checked,
        useable:     document.getElementById('itemUseable').checked,
        closeOnUse:  document.getElementById('itemCloseOnUse').checked,
    };

    const createBtn = document.getElementById('createBtn');
    createBtn.disabled = true;
    createBtn.querySelector('span').textContent = 'Creating...';

    fetch('https://spunk-itemcreator/createItem', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(data),
    }).catch(() => {}).finally(() => {
        setTimeout(() => {
            createBtn.disabled = false;
            createBtn.querySelector('span').textContent = t('btn_create');
        }, 1500);
    });
});

// ── Reset form ──
resetBtn.addEventListener('click', () => {
    itemForm.reset();
    document.getElementById('itemStack').checked    = true;
    document.getElementById('itemUseable').checked  = false;
    document.getElementById('itemCloseOnUse').checked = false;
    document.getElementById('nameError').textContent  = '';
    document.getElementById('labelError').textContent = '';
    document.getElementById('itemName').classList.remove('error');
    document.getElementById('itemLabel').classList.remove('error');
    updateImagePreview('');
    delete itemImageInput.dataset.autoFilled;
});

// ── Parse item block string from server ──
function parseItemBlock(block) {
    const item = { raw: block };
    // name
    const nameMatch = block.match(/^\s*\['([^']+)'\]/);
    if (nameMatch) item.name = nameMatch[1];
    // label
    const labelMatch = block.match(/label\s*=\s*'([^']*)'/);
    if (labelMatch) item.label = labelMatch[1];
    // weight
    const weightMatch = block.match(/weight\s*=\s*(\d+)/);
    item.weight = weightMatch ? parseInt(weightMatch[1]) : 0;
    // stack
    item.stack = /stack\s*=\s*true/.test(block);
    // useable
    item.useable = /useable\s*=\s*true/.test(block);
    // shouldClose
    item.closeOnUse = /shouldClose\s*=\s*true/.test(block);
    // image
    const imgMatch = block.match(/image\s*=\s*'([^']*)'/);
    if (imgMatch) item.image = imgMatch[1];
    // description
    const descMatch = block.match(/description\s*=\s*'([^']*)'/);
    if (descMatch) item.description = descMatch[1];

    return item;
}

// ── Render item list ──
function renderItemList(filter) {
    const fragment   = document.createDocumentFragment();
    const filterLow  = (filter || '').toLowerCase();
    let   shown      = 0;

    allItems.forEach(item => {
        if (filterLow && !item.name?.toLowerCase().includes(filterLow) && !item.label?.toLowerCase().includes(filterLow)) return;
        shown++;
        const row = buildItemRow(item);
        fragment.appendChild(row);
    });

    // Clear list except the empty state element
    Array.from(itemList.children).forEach(c => {
        if (c !== listEmpty) c.remove();
    });

    if (shown === 0) {
        listEmpty.style.display = '';
    } else {
        listEmpty.style.display = 'none';
        itemList.appendChild(fragment);
    }

    itemCountBadge.textContent = String(allItems.length);
}

function buildItemRow(item) {
    const row = document.createElement('div');
    row.className = 'item-row';
    row.dataset.name = item.name || '';

    const thumbSVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
        <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>
        <polyline points="21 15 16 10 5 21"/>
    </svg>`;

    const thumbImg = item.image
        ? `<img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.label || item.name || '')}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" /><div style="display:none;align-items:center;justify-content:center;width:100%;height:100%">${thumbSVG}</div>`
        : thumbSVG;

    const badges = [];
    if (item.stack)      badges.push(`<span class="badge badge-success">${t('toggle_stackable')}</span>`);
    if (item.useable)    badges.push(`<span class="badge badge-accent">${t('toggle_useable')}</span>`);
    if (item.closeOnUse) badges.push(`<span class="badge badge-warning">${t('toggle_close_on_use')}</span>`);

    // Source indicator
    const sourceMap = {
        'ox_inventory': { cls: 'badge-ox',   label: 'ox_inventory' },
        'database':     { cls: 'badge-db',   label: 'DB' },
        'file':         { cls: 'badge-file', label: 'File' },
    };
    const src = sourceMap[item.source];
    const sourceBadge = src
        ? `<span class="badge badge-source ${src.cls}">${src.label}</span>`
        : '';

    row.innerHTML = `
        <div class="item-row-thumb">${thumbImg}</div>
        <div class="item-row-info">
            <div class="item-row-name">${escapeHtml(item.label || item.name || 'Unknown')}</div>
            <div class="item-row-meta">
                <span class="item-row-system">${escapeHtml(item.name || '')}</span>
                <span class="item-row-weight">${item.weight}${t('list_weight_unit')}</span>
                ${item.category ? `<span class="item-row-category">${escapeHtml(item.category)}</span>` : ''}
            </div>
            ${item.description ? `<div class="item-row-desc">${escapeHtml(item.description)}</div>` : ''}
        </div>
        <div class="item-row-badges">
            ${sourceBadge}
            ${badges.join('')}
        </div>
        <button class="item-row-delete" data-name="${escapeHtml(item.name || '')}" title="${t('btn_delete')}" aria-label="${t('btn_delete')} ${escapeHtml(item.label || item.name || '')}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="3 6 5 6 21 6"/>
                <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
                <path d="M10 11v6"/><path d="M14 11v6"/>
                <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
            </svg>
        </button>
    `;

    row.querySelector('.item-row-delete').addEventListener('click', () => {
        openDeleteModal(item.name, item.label || item.name);
    });

    return row;
}

// ── Search ──
searchInput.addEventListener('input', () => renderItemList(searchInput.value));

// ── Refresh ──
refreshBtn.addEventListener('click', () => {
    refreshBtn.classList.add('loading');
    refreshBtn.disabled = true;

    fetch('https://spunk-itemcreator/refreshItems', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({}),
    }).catch(() => {}).finally(() => {
        setTimeout(() => {
            refreshBtn.classList.remove('loading');
            refreshBtn.disabled = false;
        }, 800);
    });
});

// ── Delete modal ──
function openDeleteModal(name, label) {
    pendingDelete = name;
    modalMessage.textContent = t('list_confirm_delete', label);
    deleteModal.classList.remove('hidden');
    confirmDeleteBtn.focus();
}

function closeDeleteModal() {
    deleteModal.classList.add('hidden');
    pendingDelete = null;
}

cancelDeleteBtn.addEventListener('click', closeDeleteModal);

confirmDeleteBtn.addEventListener('click', () => {
    if (!pendingDelete) return;
    fetch('https://spunk-itemcreator/deleteItem', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ name: pendingDelete }),
    }).catch(() => {});
    // Optimistically remove from local list
    allItems = allItems.filter(i => i.name !== pendingDelete);
    renderItemList(searchInput.value);
    closeDeleteModal();
});

// Close modal on overlay click
deleteModal.addEventListener('click', e => {
    if (e.target === deleteModal) closeDeleteModal();
});

// ── Preview tab ──
function showPreview(code, itemData) {
    previewEmpty.style.display  = 'none';
    previewContent.style.display = '';
    previewDot.classList.add('visible');

    // Code block
    codeContent.textContent = code;

    // Card
    cardLabel.textContent = itemData.label   || '';
    cardName.textContent  = itemData.name    || '';
    cardDesc.textContent  = itemData.description || '';

    const img = itemData.image || (itemData.name ? `${itemData.name}.png` : '');
    if (img) {
        cardImage.src     = img;
        cardImage.style.display = '';
        cardImgPlaceholder.style.display = 'none';
        cardImage.onerror = () => {
            cardImage.style.display = 'none';
            cardImgPlaceholder.style.display = 'flex';
        };
    } else {
        cardImage.style.display = 'none';
        cardImgPlaceholder.style.display = 'flex';
    }

    const badges = [];
    if (itemData.weight !== undefined) badges.push(`<span class="badge badge-muted">${itemData.weight}${t('list_weight_unit')}</span>`);
    if (itemData.stack)      badges.push(`<span class="badge badge-success">${t('toggle_stackable')}</span>`);
    if (itemData.useable)    badges.push(`<span class="badge badge-accent">${t('toggle_useable')}</span>`);
    if (itemData.closeOnUse) badges.push(`<span class="badge badge-warning">${t('toggle_close_on_use')}</span>`);
    cardBadges.innerHTML = badges.join('');
}

// ── Copy code ──
copyBtn.addEventListener('click', () => {
    const code = codeContent.textContent;
    if (!code) return;
    navigator.clipboard.writeText(code).then(() => {
        copyBtnText.textContent = t('btn_copied');
        copyBtn.classList.add('loading');
        setTimeout(() => {
            copyBtnText.textContent = t('btn_copy');
            copyBtn.classList.remove('loading');
        }, 2000);
    }).catch(() => {
        // Fallback for browsers without clipboard API
        const ta = document.createElement('textarea');
        ta.value = code;
        ta.style.cssText = 'position:fixed;opacity:0;';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
        copyBtnText.textContent = t('btn_copied');
        setTimeout(() => { copyBtnText.textContent = t('btn_copy'); }, 2000);
    });
});

// ── Toast system ──
const TOAST_ICONS = {
    success: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
    error:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    info:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
    warning: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
};

function showToast(type, message, duration = 4000) {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    const titles = { success: 'Success', error: 'Error', info: 'Info', warning: 'Warning' };

    toast.innerHTML = `
        <div class="toast-indicator"></div>
        <div class="toast-icon">${TOAST_ICONS[type] || TOAST_ICONS.info}</div>
        <div class="toast-body">
            <div class="toast-title">${titles[type] || 'Notice'}</div>
            <div class="toast-message">${escapeHtml(message)}</div>
        </div>
    `;

    toastContainer.appendChild(toast);

    const remove = () => {
        toast.classList.add('removing');
        toast.addEventListener('animationend', () => toast.remove(), { once: true });
    };

    setTimeout(remove, duration);
    toast.addEventListener('click', remove);
}

// ── NUI Message handler ──
window.addEventListener('message', function (event) {
    const data = event.data;
    if (!data || !data.action) return;

    switch (data.action) {

        case 'open':
            openUI();
            break;

        case 'close':
            app.classList.add('hidden');
            break;

        case 'setLocale':
            // Merge locale strings sent from Lua
            if (data.locale && typeof data.locale === 'object') {
                Object.assign(L, data.locale);
                applyLocale();
            }
            break;

        case 'receiveItems': {
            // data.items is an array of plain item objects sent directly from Lua
            allItems = (data.items || []).filter(i => i && i.name);
            renderItemList(searchInput.value);
            break;
        }

        case 'itemCreated': {
            // Switch to preview tab and show code + card
            showPreview(data.code, data.data || {});
            switchTab('preview');
            // Also refresh list
            if (data.data && data.data.name) {
                const exists = allItems.find(i => i.name === data.data.name);
                if (!exists) {
                    allItems.push({
                        name:        data.data.name,
                        label:       data.data.label,
                        weight:      data.data.weight || 100,
                        image:       data.data.image || `${data.data.name}.png`,
                        description: data.data.description || '',
                        stack:       data.data.stack === true || data.data.stack === 'true',
                        useable:     data.data.useable === true || data.data.useable === 'true',
                        closeOnUse:  data.data.closeOnUse === true || data.data.closeOnUse === 'true',
                    });
                    renderItemList(searchInput.value);
                }
            }
            break;
        }

        case 'notify':
            showToast(data.notifyType || 'info', data.message || '');
            break;
    }
});

// ── Keyboard: ESC closes modal first, then UI ──
document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
        if (!deleteModal.classList.contains('hidden')) {
            closeDeleteModal();
        } else if (!app.classList.contains('hidden')) {
            closeUI();
        }
    }
});

// ── Utility: escape HTML ──
function escapeHtml(str) {
    if (typeof str !== 'string') return '';
    return str
        .replace(/&/g,  '&amp;')
        .replace(/</g,  '&lt;')
        .replace(/>/g,  '&gt;')
        .replace(/"/g,  '&quot;')
        .replace(/'/g,  '&#039;');
}

// ── Dev mode: open UI immediately if not in FiveM ──
if (!window.invokeNative) {
    openUI();
    // Sample data for testing (plain objects, same format server sends)
    setTimeout(() => {
        window.dispatchEvent(new MessageEvent('message', {
            data: {
                action: 'receiveItems',
                items: [
                    { name: 'weapon_pistol',   label: 'Pistol',        weight: 900,  image: 'weapon_pistol.png',   stack: false, useable: false, closeOnUse: false, category: 'weapon',   description: 'A standard sidearm.', source: 'ox_inventory' },
                    { name: 'ammo_pistol',     label: 'Pistol Ammo',   weight: 30,   image: 'ammo_pistol.png',     stack: true,  useable: false, closeOnUse: false, category: 'ammo',     description: '',                    source: 'ox_inventory' },
                    { name: 'bread',           label: 'Bread',         weight: 150,  image: 'bread.png',           stack: true,  useable: true,  closeOnUse: true,  category: 'food',     description: 'A loaf of bread.',    source: 'ox_inventory' },
                    { name: 'water_bottle',    label: 'Water Bottle',  weight: 500,  image: 'water_bottle.png',    stack: true,  useable: true,  closeOnUse: true,  category: 'food',     description: '',                    source: 'ox_inventory' },
                    { name: 'bandage',         label: 'Bandage',       weight: 100,  image: 'bandage.png',         stack: true,  useable: true,  closeOnUse: false, category: 'medical',  description: 'Stops bleeding.',     source: 'ox_inventory' },
                    { name: 'medkit',          label: 'Medical Kit',   weight: 500,  image: 'medkit.png',          stack: false, useable: true,  closeOnUse: true,  category: 'medical',  description: 'Restores health.',    source: 'database'     },
                    { name: 'iron_ore',        label: 'Iron Ore',      weight: 250,  image: 'iron_ore.png',        stack: true,  useable: false, closeOnUse: false, category: 'material', description: 'Raw iron ore.',       source: 'database'     },
                    { name: 'phone',           label: 'Phone',         weight: 200,  image: 'phone.png',           stack: false, useable: true,  closeOnUse: false, category: 'electronic', description: 'A smartphone.',    source: 'ox_inventory' },
                    { name: 'lockpick',        label: 'Lockpick',      weight: 50,   image: 'lockpick.png',        stack: true,  useable: true,  closeOnUse: false, category: 'tool',     description: 'Picks locks.',        source: 'ox_inventory' },
                    { name: 'driver_license',  label: 'Driver License',weight: 10,   image: 'driver_license.png',  stack: false, useable: false, closeOnUse: false, category: 'document', description: '',                    source: 'ox_inventory' },
                ]
            }
        }));
    }, 300);
}
