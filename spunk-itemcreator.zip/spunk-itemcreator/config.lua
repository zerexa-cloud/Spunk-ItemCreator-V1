-- ============================================
--  spunk-itemcreator | config.lua
-- ============================================

Config = {}

-- Language: 'en' (English) or 'bg' (Bulgarian)
Config.Locale = 'en'

-- Admin groups that can use /itemcreator
-- ACE permission 'itemcreator.use' always grants access regardless of this list
Config.AdminGroups = { 'admin', 'superadmin', 'mod' }

-- Storage mode:
--   'file'     -> saves to saves/items_export.txt (no database needed)
--   'database' -> saves to MySQL database via oxmysql (recommended)
Config.StorageMode = 'database'

-- Database table name (only used when StorageMode = 'database')
Config.DBTable = 'spunk_items'

-- Command to open the item creator
Config.Command = 'itemcreator'

-- Key mapping (leave empty '' to disable default key)
Config.KeyMapping = ''

-- Notification position for ox_lib
-- Options: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left' | 'top-center' | 'bottom-center'
Config.NotifyPosition = 'top-right'

-- Notification duration in milliseconds
Config.NotifyDuration = 4000

-- Also export to flat file even when using database mode?
-- Useful as a backup / for copying to ox_inventory manually
Config.AlsoExportToFile = true

-- Show all ox_inventory items in the Item List tab (recommended: true)
-- When true, the list shows ALL registered items plus yours on top.
-- When false, shows only items created via this tool.
Config.ShowOxItems = true
