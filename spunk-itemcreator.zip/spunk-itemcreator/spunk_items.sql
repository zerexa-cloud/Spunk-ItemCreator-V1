-- ============================================================
--  spunk-itemcreator — Database Schema
--  Compatible with: MySQL 5.7+ / MariaDB 10.3+
--
--  Run this file once on your server's database to create
--  the items table used when Config.StorageMode = 'database'
-- ============================================================

-- Create the items table
CREATE TABLE IF NOT EXISTS `spunk_items` (
    `id`            INT UNSIGNED        NOT NULL AUTO_INCREMENT,
    `name`          VARCHAR(64)         NOT NULL COMMENT 'Unique system name (lowercase, a-z, 0-9, _)',
    `label`         VARCHAR(128)        NOT NULL COMMENT 'Display name shown in inventory',
    `description`   TEXT                         COMMENT 'Optional flavor text',
    `weight`        INT UNSIGNED        NOT NULL DEFAULT 100  COMMENT 'Item weight in grams',
    `image`         VARCHAR(255)        NOT NULL DEFAULT ''   COMMENT 'Image filename or full URL',
    `category`      VARCHAR(64)         NOT NULL DEFAULT ''   COMMENT 'UI category tag (weapon, food, etc.)',
    `stack`         TINYINT(1) UNSIGNED NOT NULL DEFAULT 1    COMMENT '1 = stackable, 0 = not stackable',
    `useable`       TINYINT(1) UNSIGNED NOT NULL DEFAULT 0    COMMENT '1 = can be used from inventory',
    `close_on_use`  TINYINT(1) UNSIGNED NOT NULL DEFAULT 0    COMMENT '1 = closes inventory on use (shouldClose)',
    `created_by`    VARCHAR(64)                  DEFAULT NULL COMMENT 'Steam/License identifier of creator',
    `created_at`    DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_item_name` (`name`),
    INDEX  `idx_category`   (`category`),
    INDEX  `idx_created_at` (`created_at`)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='spunk-itemcreator — managed items for ox_inventory';

-- ============================================================
--  Optional: view that formats rows as ox_inventory Lua blocks
--  (useful for manual inspection / copy-paste)
-- ============================================================
CREATE OR REPLACE VIEW `spunk_items_lua_view` AS
SELECT
    name,
    label,
    CONCAT(
        "    ['", name, "'] = {\n",
        "        label       = '", REPLACE(label, "'", "\\'"), "',\n",
        "        weight      = ", weight, ",\n",
        "        stack       = ", IF(stack = 1, 'true', 'false'), ",\n",
        "        useable     = ", IF(useable = 1, 'true', 'false'), ",\n",
        "        shouldClose = ", IF(close_on_use = 1, 'true', 'false'), ",\n",
        "        image       = '", image, "',\n",
        "        description = '", IFNULL(REPLACE(description, "'", "\\'"), ''), "',\n",
        "    },"
    ) AS lua_entry,
    created_at
FROM `spunk_items`
ORDER BY created_at DESC;

-- ============================================================
--  Example rows  (remove or comment out if not needed)
-- ============================================================
-- INSERT INTO `spunk_items`
--     (name, label, description, weight, image, category, stack, useable, close_on_use)
-- VALUES
--     ('iron_ore',    'Iron Ore',     'Raw ore mined from mountains.',  250, 'iron_ore.png',    'material', 1, 0, 0),
--     ('medkit',      'Medical Kit',  'Restores a large amount of HP.', 500, 'medkit.png',      'medical',  0, 1, 1),
--     ('coffee',      'Coffee',       'A hot cup of coffee.',            80, 'coffee.png',      'food',     1, 1, 0);
